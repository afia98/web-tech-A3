/**
 * mockDatabase.js
 * 
 * Acts as our in-memory "database" for this assignment.
 * In a real project this would be MongoDB or PostgreSQL.
 * 
 * Passwords are pre-hashed with bcrypt (salt rounds = 10).
 * Plain-text equivalents (for testing):
 *   admin@ai-genius.com    → password: admin123
 *   premium@ai-genius.com  → password: premium123
 *   free@ai-genius.com     → password: free123
 */

const bcrypt = require('bcryptjs');

// We generate hashes synchronously at startup so the mock DB is ready immediately.
const users = [
  {
    id: '1',
    email: 'admin@ai-genius.com',
    password: bcrypt.hashSync('admin123', 10),
    role: 'Admin',
  },
  {
    id: '2',
    email: 'premium@ai-genius.com',
    password: bcrypt.hashSync('premium123', 10),
    role: 'Premium_User',
  },
  {
    id: '3',
    email: 'free@ai-genius.com',
    password: bcrypt.hashSync('free123', 10),
    role: 'Free_User',
  },
];

/**
 * Whitelist of valid refresh tokens currently issued.
 * Key   = userId
 * Value = refresh token string
 * 
 * On logout or token rotation this entry is deleted/replaced.
 */
const refreshTokenStore = new Map();

// ─── Helper functions ──────────────────────────────────────────────────────────

function findUserByEmail(email) {
  return users.find((u) => u.email === email) || null;
}

function findUserById(id) {
  return users.find((u) => u.id === id) || null;
}

function saveRefreshToken(userId, token) {
  refreshTokenStore.set(userId, token);
}

function getRefreshTokenByUserId(userId) {
  return refreshTokenStore.get(userId) || null;
}

function deleteRefreshToken(userId) {
  refreshTokenStore.delete(userId);
}

module.exports = {
  findUserByEmail,
  findUserById,
  saveRefreshToken,
  getRefreshTokenByUserId,
  deleteRefreshToken,
};
