# AI-Genius – JWT Authentication & RBAC Backend

**MA 216 – Web Engineering and AI | Assignment 03**

---

## Project Structure

```
afia_eman/
├── server.js                          # Express app entry point
├── .env                               # Environment secrets (DO NOT commit)
├── .env.example                       # Template showing required keys
├── package.json
├── AI-Genius.postman_collection.json  # Postman test collection
│
├── config/
│   └── jwtUtils.js          # generateAccessToken, generateRefreshToken, verify helpers
│
├── models/
│   └── mockDatabase.js      # In-memory users array + refresh token whitelist
│
├── middleware/
│   ├── protect.js            # Reads Bearer token, verifies, attaches req.user
│   ├── restrictTo.js         # RBAC middleware factory: restrictTo('Admin', ...)
│   └── errorHandler.js       # Centralized Express error handler
│
├── controllers/
│   ├── authController.js     # login, refreshToken, logout handlers
│   └── aiController.js       # getFreeModel, postPremiumModel, purgeCache handlers
│
└── routes/
    ├── authRoutes.js         # /api/auth/*
    └── aiRoutes.js           # /api/ai/*  (protected)
```

---

## Setup & Running

### 1. Install dependencies
```bash
cd afia_eman
npm install
```

### 2. Configure environment
The `.env` file is already included. For production, copy `.env.example` and fill in real secrets:
```bash
cp .env.example .env
# then edit .env with your actual secrets
```

### 3. Start the server
```bash
npm start
# Server runs on http://localhost:3000
```

---

## API Endpoints

### Authentication

| Method | Endpoint              | Description                              |
|--------|-----------------------|------------------------------------------|
| POST   | /api/auth/login       | Login → returns accessToken + sets cookie|
| POST   | /api/auth/refresh     | Exchange refresh cookie → new accessToken|
| POST   | /api/auth/logout      | Clears refresh cookie                    |

### AI (all require Bearer token)

| Method | Endpoint                  | Allowed Roles              |
|--------|---------------------------|----------------------------|
| GET    | /api/ai/free-model        | All logged-in users        |
| POST   | /api/ai/premium-model     | Premium_User, Admin        |
| DELETE | /api/ai/purge-cache       | Admin only                 |

---

## Test Credentials

| Email                      | Password     | Role         |
|----------------------------|--------------|--------------|
| admin@ai-genius.com        | admin123     | Admin        |
| premium@ai-genius.com      | premium123   | Premium_User |
| free@ai-genius.com         | free123      | Free_User    |

---

## Testing with Postman

1. Import `AI-Genius.postman_collection.json` into Postman.
2. The collection variable `baseUrl` is set to `http://localhost:3000`.
3. Run requests in order (1 → 11) to see the full workflow.
4. The login requests auto-save the access token into `{{accessToken}}`.

### Workflow Demonstrated
1. Login as Admin → get access token
2. Access free model (200 OK)
3. Access premium model (200 OK – Admin allowed)
4. Purge cache (200 OK – Admin only)
5. Login as Free_User → try premium model (403 Forbidden)
6. Try purge cache as Premium_User (403 Forbidden)
7. Call refresh endpoint → get new access token (200 OK)
8. Logout (clears cookie)
9. Call any protected route without token (401 Unauthorized)

---

## Security Design Decisions

- **bcrypt** (salt rounds = 10): passwords are never stored in plaintext.
- **Access Token (15 min)**: short-lived, sent in JSON body, stored by client in memory.
- **Refresh Token (7 days)**: long-lived, stored in `httpOnly + secure + sameSite=strict` cookie — inaccessible to JavaScript, preventing XSS theft.
- **Refresh token whitelist**: server stores one refresh token per user; stolen/reused tokens are rejected.
- **JWT_SECRET in .env**: never hardcoded; loaded via `dotenv`.
- **Centralized error handler**: all unhandled errors produce clean JSON with appropriate HTTP status codes.
