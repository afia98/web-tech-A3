/**
 * aiController.js
 * 
 * Mock AI endpoint handlers for the AI-Genius platform.
 * Each handler simulates a real AI service response.
 */

// GET /api/ai/free-model  → All logged-in users
function getFreeModel(req, res) {
  res.status(200).json({
    status: 'success',
    message: 'Welcome to the Free AI Model!',
    model: 'ai-genius-basic-v1',
    user: req.user.email,
    role: req.user.role,
    result: 'This is a basic text generation response available to all users. Upgrade for more power!',
  });
}

// POST /api/ai/premium-model  → Premium_User and Admin only
function postPremiumModel(req, res) {
  const { prompt } = req.body;
  res.status(200).json({
    status: 'success',
    message: 'Premium AI Model accessed successfully!',
    model: 'ai-genius-premium-v3',
    user: req.user.email,
    role: req.user.role,
    prompt: prompt || '(no prompt provided)',
    result: 'High-quality AI-generated content for premium subscribers. Powered by ai-genius-premium-v3.',
  });
}

// DELETE /api/ai/purge-cache  → Admin only
function purgeCache(req, res) {
  res.status(200).json({
    status: 'success',
    message: 'AI model cache purged successfully.',
    performedBy: req.user.email,
    role: req.user.role,
    timestamp: new Date().toISOString(),
    cacheCleared: ['free-model-cache', 'premium-model-cache', 'image-gen-cache'],
  });
}

module.exports = { getFreeModel, postPremiumModel, purgeCache };
