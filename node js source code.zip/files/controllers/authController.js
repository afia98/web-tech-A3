const bcrypt = require('bcryptjs');
const db = require('../models/mockDatabase');
const { generateAccessToken, generateRefreshToken, verifyRefreshToken } = require('../config/jwtUtils');

// ─── Helper: send refresh token as httpOnly cookie ─────────────────────────────
function attachRefreshCookie(res, refreshToken) {
  res.cookie('refreshToken', refreshToken, {
    httpOnly: true,                                   // Not accessible via JavaScript
    secure: process.env.NODE_ENV === 'production',   // HTTPS only in production
    sameSite: 'strict',                               // CSRF protection
    maxAge: 7 * 24 * 60 * 60 * 1000,                 // 7 days in milliseconds
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/login
// ─────────────────────────────────────────────────────────────────────────────
async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    // 1. Validate input
    if (!email || !password) {
      return res.status(400).json({
        status: 'fail',
        message: 'Please provide both email and password.',
      });
    }

    // 2. Find user in mock DB
    const user = db.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({
        status: 'fail',
        message: 'Invalid email or password.',
      });
    }

    // 3. Compare password with bcrypt hash
    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) {
      return res.status(401).json({
        status: 'fail',
        message: 'Invalid email or password.',
      });
    }

    // 4. Generate tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    // 5. Persist refresh token in our whitelist store
    db.saveRefreshToken(user.id, refreshToken);

    // 6. Send refresh token in a secure httpOnly cookie
    attachRefreshCookie(res, refreshToken);

    // 7. Return access token in response body (client stores in memory)
    res.status(200).json({
      status: 'success',
      message: 'Logged in successfully.',
      accessToken,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
      },
    });
  } catch (err) {
    next(err);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/refresh
// ─────────────────────────────────────────────────────────────────────────────
function refreshToken(req, res, next) {
  try {
    // 1. Read refresh token from the httpOnly cookie
    const token = req.cookies.refreshToken;
    if (!token) {
      return res.status(401).json({
        status: 'fail',
        message: 'No refresh token found in cookies. Please log in again.',
      });
    }

    // 2. Verify the token signature & expiry
    let decoded;
    try {
      decoded = verifyRefreshToken(token);
    } catch (err) {
      return res.status(401).json({
        status: 'fail',
        message: 'Refresh token is invalid or expired. Please log in again.',
      });
    }

    // 3. Validate against whitelist — ensure this is not a stolen/reused token
    const storedToken = db.getRefreshTokenByUserId(decoded.id);
    if (!storedToken || storedToken !== token) {
      return res.status(403).json({
        status: 'fail',
        message: 'Refresh token has been revoked. Please log in again.',
      });
    }

    // 4. Load the user and issue a brand-new Access Token
    const user = db.findUserById(decoded.id);
    if (!user) {
      return res.status(401).json({
        status: 'fail',
        message: 'User belonging to this token no longer exists.',
      });
    }

    const newAccessToken = generateAccessToken(user);

    res.status(200).json({
      status: 'success',
      message: 'Access token refreshed successfully.',
      accessToken: newAccessToken,
    });
  } catch (err) {
    next(err);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/logout
// ─────────────────────────────────────────────────────────────────────────────
function logout(req, res, next) {
  try {
    const token = req.cookies.refreshToken;
    if (token) {
      // Try to decode WITHOUT verifying (so even expired tokens are removed cleanly)
      const bcrypt = require('bcryptjs'); // not needed here, but keeping import clean
      const jwt = require('jsonwebtoken');
      try {
        const decoded = jwt.decode(token);
        if (decoded && decoded.id) {
          db.deleteRefreshToken(decoded.id);
        }
      } catch (_) {
        // Ignore decode errors during logout
      }
    }

    // Clear the cookie
    res.clearCookie('refreshToken', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
    });

    res.status(200).json({
      status: 'success',
      message: 'Logged out successfully.',
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { login, refreshToken, logout };
