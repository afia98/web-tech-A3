const jwt = require('jsonwebtoken');

/**
 * Generate a short-lived Access Token (15 min by default).
 * Payload: id, email, role  – NO password or sensitive data.
 */
function generateAccessToken(user) {
  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
  };
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
  });
}

/**
 * Generate a long-lived Refresh Token (7 days by default).
 * Only stores the user id to keep it minimal.
 */
function generateRefreshToken(user) {
  const payload = { id: user.id };
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });
}

/**
 * Verify an Access Token.
 * Returns decoded payload on success; throws on failure.
 */
function verifyAccessToken(token) {
  return jwt.verify(token, process.env.JWT_SECRET);
}

/**
 * Verify a Refresh Token.
 * Returns decoded payload on success; throws on failure.
 */
function verifyRefreshToken(token) {
  return jwt.verify(token, process.env.JWT_REFRESH_SECRET);
}

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};
