/**
 * restrictTo - Role-Based Access Control middleware factory
 * 
 * Usage:  restrictTo('Admin', 'Premium_User')
 * 
 * Must be used AFTER the `protect` middleware so that req.user is already set.
 * Returns 403 Forbidden if the authenticated user's role is not in the allowed list.
 */
function restrictTo(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      // Should never reach here if protect runs first, but guard anyway
      return res.status(401).json({
        status: 'error',
        message: 'You are not logged in.',
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        status: 'error',
        message: `Access denied. This endpoint requires one of the following roles: ${allowedRoles.join(', ')}. Your role: ${req.user.role}.`,
      });
    }

    next();
  };
}

module.exports = restrictTo;
