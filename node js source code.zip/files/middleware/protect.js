const { verifyAccessToken } = require('../config/jwtUtils');

/**
 * protect middleware
 * 
 * Reads the Authorization: Bearer <token> header.
 * Verifies the JWT signature using JWT_SECRET.
 * Attaches the decoded payload to req.user.
 * 
 * Returns 401 if token is missing or 401/403 if token is invalid/expired.
 */
function protect(req, res, next) {
  // 1. Extract the token from the Authorization header
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      status: 'error',
      message: 'No access token provided. Please log in.',
    });
  }

  const token = authHeader.split(' ')[1];

  // 2. Verify the token
  try {
    const decoded = verifyAccessToken(token);
    req.user = decoded; // { id, email, role, iat, exp }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        status: 'error',
        message: 'Access token has expired. Please refresh your token.',
      });
    }
    return res.status(401).json({
      status: 'error',
      message: 'Invalid access token. Please log in again.',
    });
  }
}

module.exports = protect;
