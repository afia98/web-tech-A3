/**
 * errorHandler.js
 * 
 * Centralized Express error-handling middleware.
 * Must be registered LAST in server.js (after all routes).
 * 
 * Any route can call next(err) to reach this handler.
 */
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  const statusCode = err.statusCode || 500;
  const status = statusCode >= 500 ? 'error' : 'fail';

  // In development, include the stack trace for easier debugging
  const response = {
    status,
    message: err.message || 'Something went wrong on the server.',
  };

  if (process.env.NODE_ENV === 'development') {
    response.stack = err.stack;
  }

  res.status(statusCode).json(response);
}

module.exports = errorHandler;
