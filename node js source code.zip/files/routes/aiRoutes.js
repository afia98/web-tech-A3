const express = require('express');
const router = express.Router();
const protect = require('../middleware/protect');
const restrictTo = require('../middleware/restrictTo');
const { getFreeModel, postPremiumModel, purgeCache } = require('../controllers/aiController');

// All AI routes first run the protect middleware to verify the Access Token

// GET /api/ai/free-model  → All logged-in users (any valid role)
router.get('/free-model', protect, getFreeModel);

// POST /api/ai/premium-model  → Premium_User and Admin only
router.post('/premium-model', protect, restrictTo('Premium_User', 'Admin'), postPremiumModel);

// DELETE /api/ai/purge-cache  → Admin only
router.delete('/purge-cache', protect, restrictTo('Admin'), purgeCache);

module.exports = router;
