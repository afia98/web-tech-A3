const express = require('express');
const router = express.Router();
const { login, refreshToken, logout } = require('../controllers/authController');

// POST /api/auth/login
router.post('/login', login);

// POST /api/auth/refresh  — silently refreshes the access token using the httpOnly cookie
router.post('/refresh', refreshToken);

// POST /api/auth/logout
router.post('/logout', logout);

module.exports = router;
